import tkinter as tk
from tkinter import messagebox
import random
import time

DIFFICULTIES = {               #Dictionary Object: Similar to a list or an array, but the retrieval of an item is off of the first
    "easy": (9, 9, 10),        # of the paired values, rather than an index. This dictionary is initialized at the start to predetermine the
    "medium": (16, 16, 40),    # height and width of the grid, and number of bombs for each pre-set difficulty.
    "hard": (16, 30, 99)
}

class Cell:                     # In python the class keyword is used to create a custom object with variables and functions that can be called
    def __init__(self):         # or referenced later in the code.  This class, Cell, is made to represent each square in the minesweeper board.
        self.is_bomb = False    # The defined variables are used to store whether each cell object is bomb square, a revealed square (already clicked),
        self.revealed = False   # a flagged square to show that the player has marked it, and adjacent, which represents how many squares around the given
        self.flagged = False    # cell are bombs. When the main code is run, many cell objects are created to preserve the properties of each square in the grid
        self.adjacent = 0       # and each cell's variables are set with functions in the main code.

class Minesweeper_Board:
    def __init__(self, GUI, rows, cols, bombs):         # The Minesweeper_Board class is the main class of the project. It contains the functions
        self.IMAGES = {                                 # and variables used to actively initiate, play, and end the game. It accepts 4 arguments to determine
            "Bomb": tk.PhotoImage(file="bomb.png"),     # the size of the grid, the number of bombs, and the Tkinter GUI object in order to display the game
            "Flag": tk.PhotoImage(file="flag.png"),
            "Blank": tk.PhotoImage(file="blank.png"),
            "1": tk.PhotoImage(file="1.png"),
            "2": tk.PhotoImage(file="2.png"),           # This dictionary uses the PhotoImage function of the tkinter library to read images for use in the buttons
            "3": tk.PhotoImage(file="3.png"),           # when the grid is displayed. Each of these represent their respective names for the square's properties
            "4": tk.PhotoImage(file="4.png"),           # Bomb is used for each square that is a bomb when revealed, flag for each square marked with a flag during play,
            "5": tk.PhotoImage(file="5.png"),           # blank for an un-clicked cell or cell with no adjacent bombs, and numbers 1-8 for squares with adjacent bomb squares.
            "6": tk.PhotoImage(file="6.png"),
            "7": tk.PhotoImage(file="7.png"),
            "8": tk.PhotoImage(file="8.png")
        }
        self.GUI = GUI                # These are all the variables associated with the main tkinter window for the game itself. The GUI is the display
        self.rows = rows              # rows, cols, and bombs are the parameters for the grid and bomb count
        self.cols = cols
        self.bombs = bombs
        self.board = [[Cell() for co in range(cols)] for ro in range(rows)]    # board is a list of lists of cells, making a rectangular grid for the board to display
        self.buttons = []                                                      # and further reference when modifying attributes for individual cells.
        self.flags = 0                # buttons is an empty list that will be filled with another list of lists to correspond with each associated cell
        self.start_time = None        # The start_time variable is a placeholder to hold the initial time when the timer starts
        self.timer_on = None          # The timer_on variable is another placeholder used in the update_timer function later
        self.first_click = True       # This determines whether a click as been performed or not in the game, used in the on_click function.
        self.game_over = False        # Determines whether the game has concluded by clicking a bomb or revealing all non-bomb cells. Used for the win or loss box,
                                      # and stopping the timer.

        self.frame = tk.Frame(GUI)         # following large section is all using te tkinter package to properly display the components of the game
        self.frame.pack()                  # First, the frame (window) of the game is created using the established GUI in the main code.

        self.top_bar = tk.Frame(self.frame)     #Next, a rectangle is formed at the top of the window for the timer label, bomb/flag count label, and restart button
        self.top_bar.pack()
                                                                             # The following 6 lines of code create each of the aforementioned components and display them
        self.timer_label = tk.Label(self.top_bar, text="Time: 0")            # in the top_bar rectangle. Padx represents the pixel distance around the item to space it from
        self.timer_label.pack(side="left", padx=10)                          # other pieces. The pack function pushes the item to the designated side, placed next to the edge or
                                                                             # closest other item on the frame.
        self.bomb_label = tk.Label(self.top_bar, text=f"Bombs: {self.bombs}")
        self.bomb_label.pack(side="left", padx=10)

        self.restart_button = tk.Button(self.top_bar, text="Restart", command=self.restart)
        self.restart_button.pack(side="right", padx=10)

        self.board_frame = tk.Frame(self.frame)             # This creates the box where the grid of cells will be generated and placed.
        self.board_frame.pack()

        self.create_buttons()                               #Finally, the functions are called to create the board buttons, assign bomb status to cells, and calculate adjacent values
        self.place_bombs()                                  # for each cell object after all the bombs have been placed. No parameter is necessary, as all the methods
        self.update_adjacent_counts()                       # are within the same class, and thus locally available to reference in each function going forward

    def create_buttons(self):
        for r in range(self.rows):                   # One of the most difficult aspects of this project to learn is the use of lambda in these two functions.
            row = []                                 # This required a good amount of outside research and other code examination to figure out.
            for c in range(self.cols):               # Create buttons uses nested loops to create the list of lists of button objects placed in the buttons list.
                btn = tk.Button(self.board_frame, width=24, height=24, image = self.IMAGES["Blank"],command=lambda r=r, c=c: self.on_click(r, c))
                btn.image = self.IMAGES["Blank"]      #The above line creates each button object, assigning it a frame, size, image, and a command for when it is interacted with
                btn.bind("<Button-3>", lambda e, r=r, c=c: self.toggle_flag(r, c))   # in both the creation and bind function, lambda is used to make the buttons work as intended.
                btn.grid(row=r, column=c)                               # lambda represents a short function for an event (this case, a click) and then accepts new arguments before
                row.append(btn)                                         # passing on the command to run the next function. Here, it is used to preserve the row and column for the functions
            self.buttons.append(row)                                    # toggle_flag() and on.click() and run them with the correct values only when the button has been interacted with.
                                   # left-clicking reveals the cell, right-clicking places a flag. The grid function places the buttons on the frame in the specified row and column

    def restart(self):
        self.frame.destroy()                        # this function removes the parent frame, destroying the timer, bomb count, restart button, and grid buttons
        self.__init__(self.GUI, self.rows, self.cols, self.bombs)  # then, the function re-initializes the Minesweeper_Board object with the same settings, thus resetting the game

    def start_timer(self):   # this begins the timer and then calls the update_timer method below.
        self.start_time = time.time()
        self.update_timer()

    def update_timer(self):
        if self.game_over:               #This first checks whether the game has ended, and if it has, the timer will no longer update and remain at its previous value
            return
        elapsed = int(time.time() - self.start_time)           # It calculates the time passed in seconds, updates the timer label, and then continues to call itself
        self.timer_label.config(text=f"Time: {elapsed}")       # (recursion) after a 1000 millisecond (1 second) delay to continuously update the timer
        self.timer_on = self.GUI.after(1000, self.update_timer)

    def toggle_flag(self, r, c):                  # this function is called when the user right-clicks a button to place a flag.
        if self.game_over or self.board[r][c].revealed:       # if the game is over or the cell was already left-clicked (revealed) it ignores the rest of the function
            return
        cell = self.board[r][c]                             # the corresponding cell and button objects to the given row and column are recalled
        btn = self.buttons[r][c]
        if cell.flagged:                                    # it checks if there is a flag on the button and if there is one, it removes it to make the cell blank
            cell.flagged = False                            #  and subtracts one from the flag counter
            btn.config(image=self.IMAGES["Blank"])
            btn.image = self.IMAGES["Blank"]
            self.flags -= 1
        else:                                               # if there wasn't a flag, it then replaces the blank image with the flag image and then marks it as flagged
            cell.flagged = True                             # in the cell object, and adds one to the flag counter.
            btn.config(image=self.IMAGES["Flag"])
            btn.image = self.IMAGES["Flag"]
            self.flags += 1
        self.bomb_label.config(text=f"Bombs: {self.bombs - self.flags}")          # then the counter is updated by subtracting the flag total from the bomb total

    def on_click(self, r, c):
        if self.board[r][c].flagged or self.board[r][c].revealed:      # this prevents left-click interaction with revealed or flagged buttons
            return

        if self.first_click:                                #Checks if this is the first button click for the game in order to start the timer
            self.first_click = False
            self.start_timer()

        self.reveal(r, c)                               # calls the reveal function and then checks the win condition after each click
        if self.check_win():
            self.end_game(win=True)

    def reveal(self, r, c):
        cell = self.board[r][c]                   # first, it sets a local variable to a reference of the clicked-on cell
        if cell.revealed or cell.flagged:         # it checks if it as either been flagged or already pressed and terminates the function if either condition is met
            return

        btn = self.buttons[r][c]                  # sets another local variable for the corresponding button, sets the cell status to revealed,
        cell.revealed = True                      # and then visually sinks the button (pressed in) and disables interaction with it
        btn.config(relief="sunken", state="disabled")

        if cell.is_bomb:
            btn.config(image=self.IMAGES["Bomb"], bg="red")       # Now it checks for if the cell was a bomb to determine of the player loses
            btn.image = self.IMAGES["Bomb"]                       # if it is, it reveals the bomb with a red border to indicate it was clicked on and "exploded"
            self.end_game(win=False)                              # then calls the game_end method with a loss condition
            return

        if cell.adjacent > 0:                                     # if the cell is not a bomb, it checks to see if the cell's adjacent count is non-zero
            btn.config(image = self.IMAGES[str(cell.adjacent)])   # if it is, it references the dictionary of images to replace the blank square of the button with
            btn.image = self.IMAGES[str(cell.adjacent)]           # the corresponding number for adjacent bombs
        else:
            btn.config(image = self.IMAGES["Blank"])               # if it is zero (the only other possible outcome), it maintains its blank image, and then
            btn.image = self.IMAGES["Blank"]                       # follows a chain to automatically reveal all safe squares surrounding blank spaces
            for dr in [-1, 0, 1]:                                  # these nested for-loops and if condition go through the 3x3 around the clicked on cell, going from
                for dc in [-1, 0, 1]:                              # top-left to bottom-right, recurring the reveal method on the new coordinates
                    nr = r + dr                                    # if the neighboring cell is another 0 adjacent, it continues to chain this function until all valid cells
                    nc = c + dc                                    # are revealed.  The if statement below is a special condition to ensure that the code will only attempt to reveal
                    if 0 <= nr < self.rows and 0 <= nc < self.cols:   #valid coordinates within the range of the grid. Simply put, it checks the outer boundary of the grid and prevents
                        self.reveal(nr, nc)                           # the code from attempting to reveal a non-existent cell

    def end_game(self, win):          # this function reveals remaining un-flagged bombs, displays the win or loss message, and stops the timer.
        self.game_over = True
        if self.timer_on:                           #this if statement is a failsafe for cancelling the timer. if the timer_on variable has any value, given to it
            self.GUI.after_cancel(self.timer_on)    # in the update_timer function, it will allow the after_cancel function to run, which stops the timer.

        for r in range(self.rows):                  # goes through the list cells, checks if the cell is un-clicked and a bomb, and then reveals it.
            for c in range(self.cols):
                cell = self.board[r][c]
                if cell.is_bomb and not cell.revealed:
                    self.buttons[r][c].config(image = self.IMAGES["Bomb"], bg="gray")
                    self.buttons[r][c].image = self.IMAGES["Bomb"]

        if win:                                                                        # creates a new window that displays the end-game message
            messagebox.showinfo("You win!", "Minefield Clear!")
        else:
            messagebox.showinfo("Game Over", "You Failed!")

    def check_win(self):           # This function runs through the matrix of cells to determine if any un-revealed, non-bomb cells remain.
        for r in range(self.rows):      # if none remain, the player wins, if at least one remains un-marked, it returns false, continuing the game.
            for c in range(self.cols):    # If none are found, then true is returned and the player wins.
                cell = self.board[r][c]
                if not cell.is_bomb and not cell.revealed:
                    return False
        return True

    def place_bombs(self):               # to place the bombs at the beginning of the game,  it tracks the number of bombs placed and runs a loop
        placed = 0                       # once the placed number = the bombs number specified upon board creation, the loop terminates
        while placed < self.bombs:
            r = random.randint(0, self.rows - 1)       # using the random library, random integers between 0 and row size - 1  and 0 and columns - 1
            c = random.randint(0, self.cols - 1)       # (because row and column 1 is actually 0), are generated to grab a random cell off of coordinates
            if not self.board[r][c].is_bomb:              # it checks if that cells is already a bomb and if it is not, sets the cell's status to is_bomb True
                self.board[r][c].is_bomb = True           # then it updates the counter. If the cell is already a bomb, it skips it and just keeps running until enough bombs are
                placed += 1                               # placed


    def update_adjacent_counts(self):        # This function calculates and assigns the adjacent values to all non-bomb cells
        for r in range(self.rows):
            for c in range(self.cols):         #runs through each cell in the grid with the nested for loops, checks for if the current cell is a bomb
                if self.board[r][c].is_bomb:   # because the adjacent value for a bomb is unnecessary, as if you click one, you lose anyway.
                    continue
                count = 0                        # then it follows the same logic in the reveal function, checking each surrounding cell for a bomb status,
                for dr in [-1, 0, 1]:            # adding to a counter if it is. The same if statement is used to prevent trying to reference non-existent cells
                    for dc in [-1, 0, 1]:
                        nr, nc = r + dr, c + dc
                        if 0 <= nr < self.rows and 0 <= nc < self.cols:
                            if self.board[nr][nc].is_bomb:
                                count += 1                           # finally, it sets the adjacent variable to the count of adjacent bombs
                self.board[r][c].adjacent = count

def get_settings():
    difficulty = input("Difficulty (easy, medium, hard, custom): ").strip().lower()     #this line accepts a text input for difficulty, making it case-insensitive
    if difficulty in DIFFICULTIES:                                             # and removes any leading or trailing spaces
        return DIFFICULTIES[difficulty]                                        # then the previously established dictionary is referenced using the input
    else:                                                                      # to receive the established grid size and bomb count, or with any unrecognized input,
        try:                                                                   # the else reverts to custom, where the player can input the desired dimensions and bomb count
            rows = int(input("Rows: "))                                        # the try and except lines attempt to accept valid inputs, but if an error is caught
            cols = int(input("Cols: "))                                        # such as a word being entered instead of a number for number of bombs
            bombs = int(input("Bombs: "))                                      # instead of crashing, it defaults to easy mode.
            if bombs >= rows*cols:                                              # additionally, in custom settings, if the player tries to have more bombs than squares,
                print("More bombs than squares, using easy mode.")             # the code defaults to easy mode.
                return DIFFICULTIES["easy"]
            return rows, cols, bombs
        except:
            print("Invalid input, using easy mode.")
            return DIFFICULTIES["easy"]

if __name__ == "__main__":                        # This runs the min program, starting with the get_settings function to determine grid size and bomb count.
    rows, cols, bombs = get_settings()
    GUI = tk.Tk()                                 # The tkinter GUI window is established to allow for everything to be displayed, and is given the title.
    GUI.title("Minesweeper")
    app = Minesweeper_Board(GUI, rows, cols, bombs)          #The Minesweeper_Board object is created, and then mainloop() is called to then allow interaction with the board
    GUI.mainloop()                                           # and the game begins. mainloop() allows continuous interaction with the window when it comes to entering text in boxes
                                                             # and clicking buttons in tkinter